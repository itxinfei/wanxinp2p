### 万信金融-后端工程
- https://gitee.com/itxinfei/wanxinp2p

### 万信金融-前端工程
- wanxinp2p-manager  后台管理工程
- wanxinp2p-front-h5 前端用户页面